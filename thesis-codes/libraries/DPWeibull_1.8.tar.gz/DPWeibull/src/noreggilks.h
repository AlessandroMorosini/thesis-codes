void noreg_sampleloglambda(double* lambda, double alpha,
double alpha0, double lambda0,
 double* tl, double* tr,
 int* delta, int* pi, int size);


void noreg_samplealpha(double* alpha, double lambda,
double alphaalpha, double alphalambda,
 double* tl, double* tr,
 int* delta, int* pi, int size);
